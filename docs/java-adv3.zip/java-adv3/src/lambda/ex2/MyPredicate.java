package lambda.ex2;

@FunctionalInterface
public interface MyPredicate {
    boolean test(int value);
}