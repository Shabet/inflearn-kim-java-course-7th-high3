package lambda.ex2;

@FunctionalInterface
public interface StringFunction {
    String apply(String s);
}