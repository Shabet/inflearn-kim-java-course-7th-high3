package lambda.ex2;

@FunctionalInterface
public interface MyReducer {
    int reduce(int a, int b);
}