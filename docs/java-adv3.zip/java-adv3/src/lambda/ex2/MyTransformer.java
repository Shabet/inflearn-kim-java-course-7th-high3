package lambda.ex2;

@FunctionalInterface
public interface MyTransformer {
    String transform(String s);
}