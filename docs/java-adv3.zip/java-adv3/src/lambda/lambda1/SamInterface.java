package lambda.lambda1;

@FunctionalInterface
public interface SamInterface {
    void run();
}
