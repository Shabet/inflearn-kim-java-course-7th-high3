package lambda.lambda1;

public interface NotSamInterface {
    void run();
    void go();
}
