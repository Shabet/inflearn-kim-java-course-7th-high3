package lambda;

@FunctionalInterface
public interface MyFunction {
    int apply(int a, int b);
}
