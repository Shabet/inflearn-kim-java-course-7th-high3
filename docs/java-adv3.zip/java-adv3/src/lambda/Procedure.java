package lambda;

@FunctionalInterface
public interface Procedure {
    void run();
}
