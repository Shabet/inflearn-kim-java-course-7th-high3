package defaultmethod.ex1;

public interface Notifier {
    // 알림을 보내는 기능
    void notify(String message);
}
